class Task{

    constructor(isImportant, title, desc,category,dueDate,priority)
    {
        this.isImportant = isImportant;
        this.description = description;
        this.category = category;
        this.dueDate = dueDate;
        this.priority = priority;
    }
}